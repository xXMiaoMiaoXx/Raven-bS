<div align="center">
  
# Raven Bs (forked)
<p align="center">
    <a href="https://github.com/xia-mc/Raven-bS/issues">
      <img src="https://img.shields.io/github/issues/xia-mc/Raven-bS?style=flat" alt="issues" />
    </a>
    <img src="https://img.shields.io/badge/license-GPLV3-green" alt="License">
</p>

[![Github Release Downloads](https://img.shields.io/github/downloads/xia-mc/Raven-bS/total?label=Github%20Release%20Downloads&style=flat-square)](https://github.com/xia-mc/Raven-bS/releases)
<!--
[![CurseForge Downloads](http://cf.way2muchnoise.eu/997222.svg?badge_style=flat)](https://www.curseforge.com/minecraft/mc-mods/cheatdetector)
[![Modrinth Downloads](https://img.shields.io/modrinth/dt/QNVaUzHT?label=Modrinth%20Downloads&logo=Modrinth%20Downloads&style=flat-square)](https://modrinth.com/mod/cheatdetector)
-->

Raven B4, but for those who can't afford it.

![Screenshot](https://github.com/xia-mc/Raven-bS/assets/108219418/68b68ce7-2339-4cf3-8d54-622ef34aa3ba)

### ***More functionality while staying in sync with upstream branches.***
</div>

## Additional Bypass for Hypixel (Compared to [Raven-Bs](https://github.com/Strangerrrs/Raven-bS))
- TowerMove (Up Sprint Scaffold)
- Fireball LongJump (Same as Raven B4)
- Air Strafe Speed *(Patched)*
- Blink/NoGround NoFall
- Blink AntiVoid
- Client-side AntiCheat
- Criticals
- TimerRange

## Contribute
Feel free to raise an issue or submit a pull request.

If you want to co-develop this project with me, please contact me.

<img src="https://github.com/SAWARATSUKI/KawaiiLogos/blob/main/IntelliJ IDEA/IntelliJ IDEA.png" alt="Java" width="500" />
