package keystrokesmod.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class PreUpdateEvent extends Event {
}
