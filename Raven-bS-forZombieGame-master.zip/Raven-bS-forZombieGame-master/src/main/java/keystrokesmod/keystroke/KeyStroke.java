package keystrokesmod.keystroke;

public class KeyStroke {
    public static int x;
    public static int y;
    public static int currentColorNumber;
    public static boolean d;
    public static boolean e;
    public static boolean f;

    public KeyStroke() {
        x = 0;
        y = 0;
        currentColorNumber = 0;
        d = false;
        e = true;
        f = false;
    }
}
