package keystrokesmod.module.impl.render;

import keystrokesmod.module.Module;

public class NoCameraClip extends Module {
    public NoCameraClip() {
        super("NoCameraClip", category.render);
    }
}
