package keystrokesmod.clickgui.components;

public class Component {
    public void render() {
    }

    public void drawScreen(int x, int y) {
    }

    public void onClick(int x, int y, int b) {
    }

    public void mouseReleased(int x, int y, int m) {
    }

    public void keyTyped(char t, int k) {
    }

    public void so(int n) {
    }

    public int gh() {
        return 0;
    }

    public void onGuiClosed() {
    }
}
